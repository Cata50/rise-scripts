//@ author Ciyuna and Kash
//@ version 1.0
//@ description Simple Nodus themed TabGUI.

//Absolute dogshit API. Fuck you Alan <3

// MODULE
var module = rise.registerModule("Nodus clickgui ai draw", "ai tabgui horizontal draw");
module.registerSetting("boolean", "Chat Notifications", false);
module.registerSetting("boolean", "Colored Notifications", false);
module.registerSetting("boolean", "RGB Text", false);
module.registerSetting("number", "RGB Speed", 0.04, 0.0, 0.1, 0.001);
module.registerSetting("boolean", "Title", false);
module.registerSetting("boolean", "TabGUI", false);
module.registerSetting("boolean", "Arraylist", false)
module.registerSetting("boolean", "Color Settings", false);
module.registerSetting("color", "Primary", [86, 255, 221]);
module.registerSetting("color", "Secondary", [249, 81, 249]);

module.setSettingVisibility("Colored Notifications", false);
module.setSettingVisibility("RGB Speed", false);
module.setSettingVisibility("Title", false);
module.setSettingVisibility("TabGUI", false);
module.setSettingVisibility("Arraylist", false);
module.setSettingVisibility("Primary", false);
module.setSettingVisibility("Secondary", false);

var modules = [];
var font = render.getMinecraftFontRenderer();
var arrayModules = [];
var speed = 0.2; //arraylist animation speed
var padding = 1; //arraylist module spacing

var selectedCat = "Combat"; //default category
var selectedSubcat = null; //default subcategory
var submenuIndex = -1;
var subcatIndex = -1;

var cats = ["Combat", "Visual", "Movement", "Player", "World", "Exploit", "Other"]; //categories order

var subcats = { //category modules
  Combat: ["Anti Bot", "Kill Aura", "Reach", "Hitbox", "Criticals"],
  Visual: ["ESP", "Chest ESP", "Name Tags", "Free Cam", "Ambience"],
  Movement: ["Speed", "Wall Climb", "Flight", "Step", "Velocity"],
  Player: ["Manager", "Stealer", "Auto Tool", "Auto Head", "No Rotate"],
  World: ["Fast Place", "Fast Break", "Phase", "Scaffold", "Nuker"],
  Exploit: ["Disabler", "God Mode", "Console Spammer", "Client Spoofer", "TP Aura"],
  Other: ["Security Features", "Debugger", "IRC", "Rich Presence", "Translator"]
};


var enabledSubcats = {};

var lastKeyPress = 0;
var keyCooldown = 70; //key press delay (qol)

// FUNCTION ONTICK
module.handle("onTick", function(e) {
  var chatNotification = module.getSetting("Chat Notifications");
  var coloredNotification = module.getSetting("Colored Notifications");
  var textRGB = module.getSetting("RGB Text");
  var RGBSpeed = module.getSetting("RGB Speed");
  var titleRGB = module.getSetting("Title");
  var tabguiRGB = module.getSetting("TabGUI");
  var arraylistRGB = module.getSetting("Arraylist");
  var colorSettings = module.getSetting("Color Settings");
  var colorPrimary = module.getSetting("Primary");
  var colorSecondary = module.getSetting("Secondary");

  if (chatNotification) {
    module.setSettingVisibility("Colored Notifications", true);
  } else {
    module.setSettingVisibility("Colored Notifications", false);
  }

  if (textRGB) {
    module.setSettingVisibility("RGB Speed", true);
    module.setSettingVisibility("Title", true);
    module.setSettingVisibility("TabGUI", true);
    module.setSettingVisibility("Arraylist", true);
  } else {
    module.setSettingVisibility("RGB Speed", false);
    module.setSettingVisibility("Title", false);
    module.setSettingVisibility("TabGUI", false);
    module.setSettingVisibility("Arraylist", false);
  }

  if (colorSettings) {
    module.setSettingVisibility("Primary", true);
    module.setSettingVisibility("Secondary", true);
  } else {
    module.setSettingVisibility("Primary", false);
    module.setSettingVisibility("Secondary", false);
  }

  enabledSubcats = {};
  for (var i = 0; i < modules.length; i++) {
    var moduleName = modules[i][0].getName();
    enabledSubcats[moduleName] = modules[i][0].isEnabled();
  }
  return e;
});

// FUNCTION ONRENDER2D
module.handle("onRender2D", function(e) {

  //text/info display
  font.drawWithShadow("Nodus", 4, 10, [255, 255, 255]); //nodus title
  font.drawWithShadow("2.0", 38, 10, titleRGB()); //nodus title # rgb
  font.drawWithShadow("Dev Build", e.getScaledWidth() - 67, e.getScaledHeight() - 15, [255, 255, 255]); //devbuild text
  font.drawWithShadow("1.6", e.getScaledWidth() - 20, e.getScaledHeight() - 15, titleRGB()); //devguild # rgb
  font.drawWithShadow(mc.getFPS() + " FPS", 5, e.getScaledHeight() - 15, [255, 255, 255]); //fps display

  render.rectangle(2, 20, 84, 82, [255, 255, 255, 30]); //TabGUI white background

  var cats = Object.keys(subcats);
  var startY = 22;

    // Draw the categories horizontally
    var startX = 4;
    var startY = 20;
    var categoryWidth = 80;

    for (var i = 0; i < cats.length; i++) {
        var cat = cats[i];
        var isSelected = selectedCat === cat;
        var x = startX + i * categoryWidth;

        var submenuArrow = isSelected && submenuIndex === i ? "<<" : ">>"; // selected/not selected arrows
        var arrowColor = isSelected && submenuIndex === i ? tabguiRGB() : [255, 255, 255]; // tabgui rgb logic

        // draw submenu
        render.rectangle(x, startY, categoryWidth, 13, [0, 0, 0, 150]);
        font.drawWithShadow(isSelected ? "> " + cat : cat, x + 3, startY + 4, isSelected ? tabguiRGB() : colorPrimary());
        font.drawWithShadow(submenuArrow, x + categoryWidth - 15, startY + 4, arrowColor); // category arrows

        if (isSelected && submenuIndex === i) {
            var subcatList = subcats[cat];
            subcatList.sort(); // Sort subcategories alphabetically
            render.rectangle(x, startY + 11, categoryWidth, 4 + subcatList.length * 13, [255, 255, 255, 30]); // subcat white bg
            // draws out submenu in a loop w/ auto spacing
            for (var j = 0; j < subcatList.length; j++) {
                var subcat = subcatList[j];
                var isSubcatSelected = selectedSubcat === subcat;
                var subcatY = startY + 13 + j * 13; // subcat modules w/ text, bg & spacing
                var isSubcatEnabled = enabledSubcats[subcat];

                render.rectangle(x, subcatY, categoryWidth, 13, [0, 0, 0, 150]); // subcat black bg
                // tabgui rgb/white text
                if (isSubcatEnabled) {
                    font.drawWithShadow(isSubcatSelected ? "> " + subcat : subcat, x + 3, subcatY + 4, tabguiRGB());
                } else {
                    font.drawWithShadow(isSubcatSelected ? "> " + subcat : subcat, x + 3, subcatY + 4, [255, 255, 255]);
                }

                if (isSubcatSelected) {
                    subcatIndex = j;
                }
            }
        }
    }

  var targetPosition = rise.newVec2(e.getScaledWidth() - 5, 5); //arraylist x,y
  //Arraylist stuff
  for (var index = 0; index < modules.length; index++) {
    var module = modules[index];

    if (module[0].isEnabled()) {
      module[1].setX(lerp(module[1].getX(), targetPosition.getX() - module[2], speed));
      module[1].setY(lerp(module[1].getY(), targetPosition.getY(), speed));
    } else {
      if (module[1].getX() + module[2] < 0) {
        module[1].setY(targetPosition.getY());
        continue;
      }
      module[1].setX(-module[2] - 1);
    }

    var height = font.height() + padding * 2; //arraylist module spacing

    if (module[0].isEnabled()) targetPosition.setY(targetPosition.getY() + height);

    font.drawWithShadow(module[0].getName(), targetPosition.getX() - module[2] + padding / 2, module[1].getY() + padding / 2, arraylistRGB()); //arraylist RGB display
  }

  return e;
});


function lerp(a, b, c) {
  return a + c * (b - a);
}



// FUNCTION ONKEYBOARDINPUT
module.handle("onKeyboardInput", function(e) {
  var currentTime = new Date().getTime();

  if (currentTime - lastKeyPress < keyCooldown) {
    return e;
  }

  lastKeyPress = currentTime;

  var chatNotification = module.getSetting("Chat Notifications");
  var coloredNotification = module.getSetting("Colored Notifications");
  var up = input.isKeyDown(200);
  var down = input.isKeyDown(208);
  var left = input.isKeyDown(203);
  var right = input.isKeyDown(205);

  var cats = Object.keys(subcats);
  var currentIndex = cats.indexOf(selectedCat);
  var subcatList = subcats[selectedCat];
  var subcatCount = subcatList.length;

  // Controls for menus
  if (up || down || left || right) {
    if (up) {
      if (submenuIndex === -1) {
        var newIndex = (currentIndex - 1 + cats.length) % cats.length;
        selectedCat = cats[newIndex];
      } else {
        subcatIndex = (subcatIndex - 1 + subcatCount) % subcatCount;
        selectedSubcat = subcatList[subcatIndex];
      }
    } else if (down) {
      if (submenuIndex === -1) {
        var newIndex = (currentIndex + 1) % cats.length;
        selectedCat = cats[newIndex];
      } else {
        subcatIndex = (subcatIndex + 1) % subcatCount;
        selectedSubcat = subcatList[subcatIndex];
      }
    } else if (right) {
      if (submenuIndex === -1) {
        submenuIndex = currentIndex;
      } else if (selectedSubcat === null) {
        selectedSubcat = subcatList[0];
        subcatIndex = 0;
      } else {
        if (enabledSubcats[selectedSubcat]) {
          var toggle = rise.getModule(selectedSubcat);
          toggle.setEnabled(false);
          if (chatNotification) {
            if (!coloredNotification) {
              rise.displayChat("Disabled " + selectedSubcat);
            } else {
              rise.displayChat("\u00A7c" + selectedSubcat);
            }
          }
          delete enabledSubcats[selectedSubcat];
        } else {
          enabledSubcats[selectedSubcat] = true;
          var toggle = rise.getModule(selectedSubcat);
          toggle.setEnabled(true);
          if (chatNotification) {
            if (!coloredNotification) {
              rise.displayChat("Enabled " + selectedSubcat);
            } else {
              rise.displayChat("\u00A7a" + selectedSubcat);
            }
          }
        }
      }
    } 
    if (submenuIndex !== -1) {
      if (right && selectedSubcat === null) { //check if no subcategory is selected
        selectedSubcat = subcatList[0]; //default subcat arrow (first module)
        subcatIndex = 0;
      } else if (left) {
        submenuIndex = -1;
        selectedSubcat = null;
        subcatIndex = -1;
      }
    }
  }

  return e;
});


// COLOR FUNCTIONS

//RGB function
function getOldRainbowColor() {
    var frequency = module.getSetting("RGB Speed");
    var phase = Date.now() * frequency;
    var center = 128;
    var width = 127;
    var red = Math.sin(frequency * phase + 2) * width + center;
    var green = Math.sin(frequency * phase + 0) * width + center;
    var blue = Math.sin(frequency * phase + 4) * width + center;

    return [red, green, blue];
}


//RGB function
function getNewRainbowColor() {
    var frequency = module.getSetting("RGB Speed");
    var phase = Date.now() * frequency;
    var center = 128;
    var width = 127;
    var red = Math.sin(frequency * phase + 2) * width + center;
    var green = Math.sin(frequency * phase + 0) * width + center;
    var blue = Math.sin(frequency * phase + 4) * width + center;

    return [red, green, blue];
}
//arraylist RGB
function arraylistRGB() {
    var arraylistRGBEnabled = module.getSetting("Arraylist");
    var textRGBEnabled = module.getSetting("RGB Text");

    if (textRGBEnabled && arraylistRGBEnabled) {
        return getNewRainbowColor();
    } else {
        return [255, 255, 255];
    }
}

//TabGUI RGB
function tabguiRGB() {
    var tabguiRGBEnabled = module.getSetting("TabGUI");
    var textRGBEnabled = module.getSetting("RGB Text");

    if (textRGBEnabled && tabguiRGBEnabled) {
        return getNewRainbowColor();
    } else {
        return [86, 255, 221];
    }
}

//title RGB
function titleRGB() {
    var titleRGBEnabled = module.getSetting("Title");
    var textRGBEnabled = module.getSetting("RGB Text");

    if (textRGBEnabled && titleRGBEnabled) {
        return getNewRainbowColor();
    } else {
        return [255, 255, 255];
    }
}

//primary color
function colorPrimary() {
    var colorSettingsEnabled = module.getSetting("Color Settings");
    var colorPrimary = colorSettingsEnabled ? module.getSetting("Primary") : [255, 255, 255];
    return colorPrimary;
}

//secondary color
function colorSecondary() {
    var colorSettingsEnabled = module.getSetting("Color Settings");
    var colorSecondary = colorSettingsEnabled ? module.getSetting("Secondary") : [86, 255, 221];
    return colorSecondary;
}

// ON ENABLE
module.handle("onEnable", function(e) {
  rise.setName("");
  modules = [];
  var unprocessedModules = rise.getModules();

  modules = [];

  for (var index = 0; index < unprocessedModules.length; index++) {
    modules[index] = [unprocessedModules[index], rise.newVec2(0, 0), font.width(unprocessedModules[index].getName())];
  }

  modules.sort(
    function(a, b) {
      return font.width(b[0].getName()) - font.width(a[0].getName());
    }
  );
});



// ON DISABLE
module.handle("onDisable", function(e) {
  rise.setName("Rise");
});

// UNLOAD
script.handle("onUnload", function() {
  module.unregister();
});
