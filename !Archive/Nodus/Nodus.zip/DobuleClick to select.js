//Credit to cata50 for giving me this list lol
var module = rise.registerModule("nodus old dc selc", "double click to select subcat")
var modules = []
var font = render.getMinecraftFontRenderer()
var freecam = rise.getModule("Freecam");
var freelook = rise.getModule("Freelook");
var legitScaffold = rise.getModule("LegitScaffold");
var safeWalk = rise.getModule("Safewalk");
var timer = rise.getModule("Timer");
var stuck = rise.getModule("Stuck");
var flight = rise.getModule("Flight");
var phase = rise.getModule("Phase");
var noclip = rise.getModule("NoClip");
var longJump = rise.getModule("LongJump");
var wallClimb = rise.getModule("WallClimb");
var step = rise.getModule("Step");
var strafe = rise.getModule("Strafe");
var speed = rise.getModule("Speed");
var tickbase = rise.getModule("Tickbase");
var crasher = rise.getModule("Crasher");
var fences = rise.getModule("Fences");
var killAura = rise.getModule("KillAura");
var teleportAura = rise.getModule("TeleportAura");
var godMode = rise.getModule("GodMode");
var comboOneHit = rise.getModule("ComboOneHit");
var velocity = rise.getModule("Velocity");
var scaffold = rise.getModule("Scaffold");
var manager = rise.getModule("Manager");
var blink = rise.getModule("Blink");
var noFall = rise.getModule("NoFall");
var autoTool = rise.getModule("AutoTool");
var breaker = rise.getModule("Breaker");
var antiVoid = rise.getModule("AntiVoid");
var fastBreak = rise.getModule("FastBreak");
var fastPlace = rise.getModule("FastPlace");
var criticals = rise.getModule("Criticals");
var antiBot = rise.getModule("AntiBot");
var reach = rise.getModule("Reach");
var chestESP = rise.getModule("ChestESP");
var playerESP = rise.getModule("ESP");
var tracers = rise.getModule("Tracers");
var nametags = rise.getModule("Nametags");
var brightness = rise.getModule("FullBright");

script.handle("onUnload", function () {
    module.unregister()
})

module.handle("onEnable", function (e) {
    clientName = "Nodus"
    rise.setName(clientName)
    modules = []

})

var selectedCat = "Player";
var selectedSubcat = null;
var submenuIndex = -1;
var subcatIndex = -1;

var subcats = {
  Player: ["Manager", "Stealer", "AutoTool", "Flight", "Timer"],
  World: ["Fastplace", "Fastbreak", "Phase", "Scaffold", "AntiVoid"],
  Display: ["Brightness", "ChestESP", "Nametags", "PlayerESP", "Tracers"],
  Combat: ["Killaura", "Velocity", "Criticals", "Antibot", "Reach"]
};

var enabledSubcats = {};

module.handle("onRender2D", function (e) {
  font.draw("Nodus 2.0", 4, 10, [255, 255, 255]);
  render.rectangle(2, 20, 84, 56, [255, 255, 255, 50]);

  var cats = Object.keys(subcats);
  var startY = 22;

  for (var i = 0; i < cats.length; i++) {
    var cat = cats[i];
    var isSelected = selectedCat === cat;
    var y = startY + i * 13;
    var submenuArrow = isSelected && submenuIndex === i ? "<<" : ">>";
    var arrowColor = isSelected && submenuIndex === i ? [86, 255, 221] : [255, 255, 255];

    render.rectangle(4, y, 80, 13, [0, 0, 0, 125]);
    font.drawWithShadow(isSelected ? "> " + cat : cat, 7, y + 4, [255, 255, 255]);
    font.drawWithShadow(submenuArrow, 72, y + 4, arrowColor);

    if (isSelected && submenuIndex === i) {
      var subcatList = subcats[cat];
      render.rectangle(88, y - 2, 88, 4 + subcatList.length * 13, [255, 255, 255, 50]);

      for (var j = 0; j < subcatList.length; j++) {
        var subcat = subcatList[j];
        var isSubcatSelected = selectedSubcat === subcat;
        var subcatY = y + j * 13;
        var isSubcatEnabled = enabledSubcats[subcat];

        render.rectangle(90, subcatY, 84, 13, [0, 0, 0, 125]);
        if (isSubcatEnabled) {
          font.drawWithShadow(isSubcatSelected ? "> " + subcat : subcat, 93, subcatY + 4, [86, 255, 221]);
        } else {
          font.drawWithShadow(isSubcatSelected ? "> " + subcat : subcat, 93, subcatY + 4, [255, 255, 255]);
        }

        if (isSubcatSelected) {
          subcatIndex = j;
        }
      }
    }
  }

  return e;
});

module.handle("onKeyboardInput", function (e) {
  var up = input.isKeyDown(200);
  var down = input.isKeyDown(208);
  var left = input.isKeyDown(203);
  var right = input.isKeyDown(205);

  var cats = Object.keys(subcats);
  var currentIndex = cats.indexOf(selectedCat);
  var subcatList = subcats[selectedCat];
  var subcatCount = subcatList.length;

  if (up) {
    if (submenuIndex === -1) {
      var newIndex = (currentIndex - 1 + cats.length) % cats.length;
      selectedCat = cats[newIndex];
    } else {
      subcatIndex = (subcatIndex - 1 + subcatCount) % subcatCount;
      selectedSubcat = subcatList[subcatIndex];
    }
  }

  if (down) {
    if (submenuIndex === -1) {
      var newIndex = (currentIndex + 1) % cats.length;
      selectedCat = cats[newIndex];
    } else {
      subcatIndex = (subcatIndex + 1) % subcatCount;
      selectedSubcat = subcatList[subcatIndex];
    }
  }

  if (right) {
    if (submenuIndex === -1) {
      submenuIndex = currentIndex;
    } else if (selectedSubcat === null) {
      selectedSubcat = subcatList[0];
      subcatIndex = 0;
    } else {
      if (enabledSubcats[selectedSubcat]) {
        rise.displayChat("Disabled " + selectedSubcat)
        delete enabledSubcats[selectedSubcat];
      } else {
        enabledSubcats[selectedSubcat] = true;
        rise.displayChat("Enabled " + selectedSubcat)
      }
    }
  }

  if (left) {
    if (submenuIndex !== -1) {
      submenuIndex = -1;
      selectedSubcat = null;
      subcatIndex = -1;
    }
  }

  return e;
});

