// MODULE
var module = rise.registerModule("HORION BETA", "Nodus Rewrite...");
module.registerSetting("boolean", "RGB Text", false);
module.registerSetting("number", "RGB Speed", 0.04, 0.0, 0.1, 0.001);
module.registerSetting("boolean", "TabGUI", false);
module.registerSetting("boolean", "Arraylist", false)
module.registerSetting("color", "Primary", [152, 152, 152]);
module.registerSetting("color", "Secondary", [255, 255, 255]);

module.setSettingVisibility("RGB Speed", false);
module.setSettingVisibility("TabGUI", false);
module.setSettingVisibility("Arraylist", false);

var modules = [];
var font = render.getMinecraftFontRenderer();
var arrayModules = [];
var speed = 0.2; //arraylist animation speed
var padding = 1; //arraylist module spacing

var selectedCat = "Combat"; //default category
var selectedSubcat = null; //default subcategory
var submenuIndex = -1;
var subcatIndex = -1;

var cats = ["Combat", "Visual", "Movement", "Player", "World", "Misc", "GUI"]; //categories order

var subcats = { //category modules
    Combat: ["Anti Bot", "Kill Aura", "Reach", "Hitbox", "Criticals"],
    Visual: ["ESP", "Chest ESP", "Name Tags", "Free Cam", "Ambience"],
    Movement: ["Speed", "Wall Climb", "Flight", "Step", "Velocity"],
    Player: ["Manager", "Stealer", "Auto Tool", "Auto Head", "No Rotate"],
    World: ["Fast Place", "Fast Break", "Phase", "Scaffold", "Nuker"],
    Misc: ["Security Features", "Debugger", "IRC", "Rich Presence", "Translator"],
    GUI: ["horion", "client", "has", "best", "visuals"],
};


var enabledSubcats = {};

var lastKeyPress = 0;
var keyCooldown = 70; //key press delay (qol)

// FUNCTION ONTICK
module.handle("onTick", function (e) {
    var textRGB = module.getSetting("RGB Text");
    var RGBSpeed = module.getSetting("RGB Speed");
    var tabguiRGB = module.getSetting("TabGUI");
    var arraylistRGB = module.getSetting("Arraylist");
    var colorPrimary = module.getSetting("Primary");
    var colorSecondary = module.getSetting("Secondary");

    if (textRGB) {
        module.setSettingVisibility("RGB Speed", true);
        module.setSettingVisibility("TabGUI", true);
        module.setSettingVisibility("Arraylist", true);
    } else {
        module.setSettingVisibility("RGB Speed", false);
        module.setSettingVisibility("TabGUI", false);
        module.setSettingVisibility("Arraylist", false);
    }

    enabledSubcats = {};
    for (var i = 0; i < modules.length; i++) {
        var moduleName = modules[i][0].getName();
        enabledSubcats[moduleName] = modules[i][0].isEnabled();
    }
    return e;
});

// FUNCTION ONRENDER2D
module.handle("onRender2D", function (e) {
    render.roundedRectangle(4, 20, 80, 95, 5, [0, 0, 0, 150]); // tabGUI black bg

    var cats = Object.keys(subcats);
    var startY = 22;

    // Category looper that draws the modules
    for (var i = 0; i < cats.length; i++) {
        var cat = cats[i];
        var isSelected = selectedCat === cat;
        var y = startY + i * 13;

        // Adjust x-coordinate for both arrow and text when category is selected
        font.drawWithShadow(isSelected ? "> " + cat : cat, isSelected ? 10 : 10, y + 4, isSelected ? tabguiRGB() : colorPrimary()); //arrow & category space from edge

        if (isSelected && submenuIndex === i) {
            // Generate a single background for the category
            render.roundedRectangle(90, y, 90, subcats[cat].length * 13, 5, [0, 0, 0, 150]); // subcat black bg

            var subcatList = subcats[cat];
            // draws out submenu in a loop w/ auto spacing
            for (var j = 0; j < subcatList.length; j++) {
                var subcat = subcatList[j];
                var isSubcatSelected = selectedSubcat === subcat;
                var subcatY = y + j * 13; // subcat modules w/ text, bg & spacing
                var isSubcatEnabled = enabledSubcats[subcat];

                // tabgui rgb/white text
                if (isSubcatEnabled) {
                    font.drawWithShadow(isSubcatSelected ? "> " + subcat : subcat, 93, subcatY + 4, colorSecondary()); //disabled module color
                } else {
                    font.drawWithShadow(isSubcatSelected ? "> " + subcat : subcat, 93, subcatY + 4, colorPrimary()); //enabled module color
                }
            }
        }
    }

    var targetPosition = rise.newVec2(e.getScaledWidth() - 5, 5); // arraylist x,y
    // Arraylist stuff
    for (var index = 0; index < modules.length; index++) {
        var module = modules[index];

        if (module[0].isEnabled()) {
            module[1].setX(lerp(module[1].getX(), targetPosition.getX() - module[2], speed));
            module[1].setY(lerp(module[1].getY(), targetPosition.getY(), speed));
        } else {
            if (module[1].getX() + module[2] < 0) {
                module[1].setY(targetPosition.getY());
                continue;
            }
            module[1].setX(-module[2] - 1);
        }

        var height = font.height() + padding * 2; // arraylist module spacing

        if (module[0].isEnabled()) targetPosition.setY(targetPosition.getY() + height);

        font.drawWithShadow(module[0].getName(), targetPosition.getX() - module[2] + padding / 2, module[1].getY() + padding / 2, arraylistRGB()); // arraylist RGB display
    }

    return e;
});









function lerp(a, b, c) {
    return a + c * (b - a);
}



// FUNCTION ONKEYBOARDINPUT
module.handle("onKeyboardInput", function (e) {
    var currentTime = new Date().getTime();

    if (currentTime - lastKeyPress < keyCooldown) {
        return e;
    }

    lastKeyPress = currentTime;

    var up = input.isKeyDown(200);
    var down = input.isKeyDown(208);
    var left = input.isKeyDown(203);
    var right = input.isKeyDown(205);
    var insert = input.isKeyDown(210);

    var cats = Object.keys(subcats);
    var currentIndex = cats.indexOf(selectedCat);
    var subcatList = subcats[selectedCat];
    var subcatCount = subcatList.length;

    // Controls for menus
    if (up || down || left || right || insert) {
        if (up) {
            if (submenuIndex === -1) {
                var newIndex = (currentIndex - 1 + cats.length) % cats.length;
                selectedCat = cats[newIndex];
            } else {
                subcatIndex = (subcatIndex - 1 + subcatCount) % subcatCount;
                selectedSubcat = subcatList[subcatIndex];
            }
        } else if (down) {
            if (submenuIndex === -1) {
                var newIndex = (currentIndex + 1) % cats.length;
                selectedCat = cats[newIndex];
            } else {
                subcatIndex = (subcatIndex + 1) % subcatCount;
                selectedSubcat = subcatList[subcatIndex];
            }
        } else if (right) {
            if (submenuIndex === -1) {
                submenuIndex = currentIndex;
            } else if (selectedSubcat === null) {
                selectedSubcat = subcatList[0];
                subcatIndex = 0;
            } else {
                if (enabledSubcats[selectedSubcat]) {
                    var toggle = rise.getModule(selectedSubcat);
                    toggle.setEnabled(false);
                    delete enabledSubcats[selectedSubcat];
                } else {
                    enabledSubcats[selectedSubcat] = true;
                    var toggle = rise.getModule(selectedSubcat);
                    toggle.setEnabled(true);
                }
            }
        }
        if (submenuIndex !== -1) {
            if (right && selectedSubcat === null) { //check if no subcategory is selected
                selectedSubcat = subcatList[0]; //default subcat arrow (first module)
                subcatIndex = 0;
            } else if (left) {
                submenuIndex = -1;
                selectedSubcat = null;
                subcatIndex = -1;
            }
        }
    }

    return e;
});


// COLOR FUNCTIONS

//RGB function
function getOldRainbowColor() {
    var frequency = module.getSetting("RGB Speed");
    var phase = Date.now() * frequency;
    var center = 128;
    var width = 127;
    var red = Math.sin(frequency * phase + 2) * width + center;
    var green = Math.sin(frequency * phase + 0) * width + center;
    var blue = Math.sin(frequency * phase + 4) * width + center;

    return [red, green, blue];
}


//RGB function
function getNewRainbowColor() {
    var frequency = module.getSetting("RGB Speed");
    var phase = Date.now() * frequency;
    var center = 128;
    var width = 127;
    var red = Math.sin(frequency * phase + 2) * width + center;
    var green = Math.sin(frequency * phase + 0) * width + center;
    var blue = Math.sin(frequency * phase + 4) * width + center;

    return [red, green, blue];
}
//arraylist RGB
function arraylistRGB() {
    var arraylistRGBEnabled = module.getSetting("Arraylist");
    var textRGBEnabled = module.getSetting("RGB Text");

    if (textRGBEnabled && arraylistRGBEnabled) {
        return getNewRainbowColor();
    } else {
        return [255, 255, 255];
    }
}

//tabGUI RGB
function tabguiRGB() {
    var tabguiRGBEnabled = module.getSetting("TabGUI");
    var textRGBEnabled = module.getSetting("RGB Text");
    var primaryColor = module.getSetting("Primary");

    if (textRGBEnabled && tabguiRGBEnabled) {
        return getNewRainbowColor();
    } else {
        return primaryColor;
    }
}

//primary color
function colorPrimary() {
    var primaryColor = module.getSetting("Primary");

    return primaryColor;
}

//secondary color
function colorSecondary() {
    var colorSecondary = module.getSetting("Secondary");

    return colorSecondary;
}

// ON ENABLE
module.handle("onEnable", function (e) {
    var interface = rise.getModule("Interface");
    interface.setEnabled(false);

    rise.setName("");
    modules = [];
    var unprocessedModules = rise.getModules();

    modules = [];

    for (var index = 0; index < unprocessedModules.length; index++) {
        modules[index] = [unprocessedModules[index], rise.newVec2(0, 0), font.width(unprocessedModules[index].getName())];
    }

    modules.sort(
        function (a, b) {
            return font.width(b[0].getName()) - font.width(a[0].getName());
        }
    );
});



// ON DISABLE
module.handle("onDisable", function (e) {
    var interface = rise.getModule("Interface");
    interface.setEnabled(false);
    rise.setName("Rise");
});

// UNLOAD
script.handle("onUnload", function () {
    module.unregister();
});
